/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto.estructuras;

/**
 *
 * @author arjoz
 */
public class Datos {
    private String Nombre;
    private String Apellidos;
    private  String Nickname;
    private  boolean estadoDeCuenta;
    
    
    public Datos(){
      this.Nombre="";
      this.Apellidos="";
      this.Nickname= "";
      this.estadoDeCuenta = false;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellidos() {
        return Apellidos;
    }

    public void setApellidos(String Apellidos) {
        this.Apellidos = Apellidos;
    }

    public String getNickname() {
        return Nickname;
    }

    public void setNickname(String Nickname) {
        this.Nickname = Nickname;
    }

    public boolean isEstadoDeCuenta() {
        return estadoDeCuenta;
    }

    public void setEstadoDeCuenta(boolean estadoDeCuenta) {
        this.estadoDeCuenta = estadoDeCuenta;
    }
    
    
}
