/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto.estructuras;

/**
 *
 * @author arjoz
 */
public class NodoCRegitroUsuarios {
    private Datos elemento;
  private NodoCRegitroUsuarios siguiente;
  
  public NodoCRegitroUsuarios (){
  this.siguiente = null;
  }

    public Datos getElemento() {
        return elemento;
    }

    public void setElemento(Datos elemento) {
        this.elemento = elemento;
    }

    public NodoCRegitroUsuarios getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoCRegitroUsuarios siguiente) {
        this.siguiente = siguiente;
    }
  
  
}
